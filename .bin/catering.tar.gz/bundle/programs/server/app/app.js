var require = meteorInstall({"lib":{"collections":{"cooks.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/collections/cooks.js                                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Cooks = new Mongo.Collection("cooks");                                                                        // 1
cukes = Cooks;                                                                                                    // 2
module.export("default",exports.default=(Cooks));                                                                 // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"rehearsals.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/collections/rehearsals.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Rehearsals = new Mongo.Collection("rehearsals");                                                              // 1
module.export("default",exports.default=(Rehearsals));                                                            // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"accounts-config.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/accounts-config.js                                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
AccountsTemplates.configure({                                                                                     // 1
  forbidClientAccountCreation: true,                                                                              // 2
  hideSignUpLink: true                                                                                            // 3
});                                                                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cooks-list.js":["babel-runtime/helpers/classCallCheck","./collections/cooks",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/cooks-list.js                                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({CANNONICAL_COOKS:function(){return CANNONICAL_COOKS}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var Cooks;module.import('./collections/cooks',{"default":function(v){Cooks=v}});
                                                                                                                  // 1
                                                                                                                  //
// DON'T FORGET TO REFRESH THE COOKS COLLECTION IF YOU MAKE CHANGES!                                              // 3
var CANNONICAL_COOKS = ['thomas', 'ian', 'alex', 'jeff', 'adriana', 'dane'];                                      // 4
                                                                                                                  //
var cooksDep = new Tracker.Dependency();                                                                          // 6
                                                                                                                  //
function generateFollowers() {                                                                                    // 8
  var followers = {};                                                                                             // 9
  for (var i = 0; i < CANNONICAL_COOKS.length; i++) {                                                             // 10
    var thisCook = CANNONICAL_COOKS[i];                                                                           // 11
    var nextCook = null;                                                                                          // 12
    if (CANNONICAL_COOKS[i + 1]) {                                                                                // 13
      nextCook = CANNONICAL_COOKS[i + 1];                                                                         // 14
    } else {                                                                                                      // 15
      nextCook = CANNONICAL_COOKS[0];                                                                             // 16
    }                                                                                                             // 17
    followers[thisCook] = nextCook;                                                                               // 18
  }                                                                                                               // 19
  return followers;                                                                                               // 20
}                                                                                                                 // 21
                                                                                                                  //
var followers = generateFollowers();                                                                              // 23
                                                                                                                  //
var CooksList = function () {                                                                                     //
  function CooksList() {                                                                                          // 26
    _classCallCheck(this, CooksList);                                                                             // 26
                                                                                                                  //
    this.dependency = cooksDep;                                                                                   // 27
  }                                                                                                               // 28
                                                                                                                  //
  CooksList.prototype.prepend = function () {                                                                     //
    function prepend(name) {                                                                                      //
      var cooks = this.readCooks();                                                                               // 31
      cooks.unshift(name);                                                                                        // 32
      this.writeCooks(cooks);                                                                                     // 33
    }                                                                                                             // 34
                                                                                                                  //
    return prepend;                                                                                               //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.getAt = function () {                                                                       //
    function getAt(i) {                                                                                           //
      var cooks = this.readCooks();                                                                               // 37
      this.ensureIndexExists(i);                                                                                  // 38
      return cooks[i];                                                                                            // 39
    }                                                                                                             // 40
                                                                                                                  //
    return getAt;                                                                                                 //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.cooked = function () {                                                                      //
    function cooked() {                                                                                           //
      this.generateNextCook();                                                                                    // 43
      var cooks = this.readCooks();                                                                               // 44
      cooks.shift();                                                                                              // 45
      this.writeCooks(cooks);                                                                                     // 46
    }                                                                                                             // 47
                                                                                                                  //
    return cooked;                                                                                                //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.setAt = function () {                                                                       //
    function setAt(i, name) {                                                                                     //
      var cooks = this.readCooks();                                                                               // 50
      this.ensureIndexExists(i);                                                                                  // 51
      cooks[i] = name;                                                                                            // 52
      this.writeCooks(cooks);                                                                                     // 53
    }                                                                                                             // 54
                                                                                                                  //
    return setAt;                                                                                                 //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.deleteAt = function () {                                                                    //
    function deleteAt(index) {                                                                                    //
      this.generateNextCook();                                                                                    // 57
      var cooks = this.readCooks();                                                                               // 58
      cooks.splice(index, 1);                                                                                     // 59
      this.writeCooks(cooks);                                                                                     // 60
    }                                                                                                             // 61
                                                                                                                  //
    return deleteAt;                                                                                              //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.insertAt = function () {                                                                    //
    function insertAt(index, name) {                                                                              //
      var cooks = this.readCooks();                                                                               // 64
      cooks.splice(index, 0, name);                                                                               // 65
      this.writeCooks(cooks);                                                                                     // 66
    }                                                                                                             // 67
                                                                                                                  //
    return insertAt;                                                                                              //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.swap = function () {                                                                        //
    function swap(i1, i2) {                                                                                       //
      var firstPerson = this.getAt(i1);                                                                           // 70
      var secondPerson = this.getAt(i2);                                                                          // 71
      this.setAt(i1, secondPerson);                                                                               // 72
      this.setAt(i2, firstPerson);                                                                                // 73
    }                                                                                                             // 74
                                                                                                                  //
    return swap;                                                                                                  //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.ensureIndexExists = function () {                                                           //
    function ensureIndexExists(i) {                                                                               //
      var cooks = this.readCooks();                                                                               // 77
      var lastIndex = cooks.length - 1;                                                                           // 78
      while (i > lastIndex) {                                                                                     // 79
        this.generateNextCook();                                                                                  // 80
        cooks = this.readCooks();                                                                                 // 81
        lastIndex = cooks.length - 1;                                                                             // 82
      }                                                                                                           // 83
    }                                                                                                             // 84
                                                                                                                  //
    return ensureIndexExists;                                                                                     //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.generateNextCook = function () {                                                            //
    function generateNextCook() {                                                                                 //
      var cooks = this.readCooks();                                                                               // 87
      var lastIndex = cooks.length - 1;                                                                           // 88
      var lastCook = cooks[lastIndex];                                                                            // 89
      var nextCook = this.whoFollows(lastCook);                                                                   // 90
      cooks.push(nextCook);                                                                                       // 91
      this.writeCooks(cooks);                                                                                     // 92
    }                                                                                                             // 93
                                                                                                                  //
    return generateNextCook;                                                                                      //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.whoFollows = function () {                                                                  //
    function whoFollows(name) {                                                                                   //
      return followers[name];                                                                                     // 96
    }                                                                                                             // 97
                                                                                                                  //
    return whoFollows;                                                                                            //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.readCooks = function () {                                                                   //
    function readCooks() {                                                                                        //
      cooksDep.depend();                                                                                          // 100
      this.checkCooks();                                                                                          // 101
      var doc = Cooks.findOne({});                                                                                // 102
      if (doc) {                                                                                                  // 103
        return doc.value;                                                                                         // 104
      }                                                                                                           // 105
    }                                                                                                             // 106
                                                                                                                  //
    return readCooks;                                                                                             //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.checkCooks = function () {                                                                  //
    function checkCooks() {                                                                                       //
      if (Meteor.isServer) {                                                                                      // 109
        var docs = Cooks.find({}).fetch();                                                                        // 110
        if (docs.length > 1) {                                                                                    // 111
          throw new Error('Found more than one cooks document in the cooks collection: ' + JSON.stringify(docs));
        } else if (docs.length === 0) {                                                                           // 113
          throw new Error('No documents in Cooks collection.');                                                   // 114
        } else if (docs[0] && !docs[0].value) {                                                                   // 115
          throw new Error('Document is missing value property');                                                  // 116
        }                                                                                                         // 117
      }                                                                                                           // 118
    }                                                                                                             // 119
                                                                                                                  //
    return checkCooks;                                                                                            //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.writeCooks = function () {                                                                  //
    function writeCooks(cooks) {                                                                                  //
      this.checkCooks();                                                                                          // 122
      var doc = Cooks.findOne({});                                                                                // 123
      if (doc) {                                                                                                  // 124
        Cooks.update(doc._id, { $set: { value: cooks } });                                                        // 125
      } else {                                                                                                    // 126
        console.log('Inserting cooks');                                                                           // 127
        Cooks.insert({ value: cooks });                                                                           // 128
      }                                                                                                           // 129
      cooksDep.changed();                                                                                         // 130
    }                                                                                                             // 131
                                                                                                                  //
    return writeCooks;                                                                                            //
  }();                                                                                                            //
                                                                                                                  //
  CooksList.prototype.count = function () {                                                                       //
    function count() {                                                                                            //
      return this.readCooks().length;                                                                             // 134
    }                                                                                                             // 135
                                                                                                                  //
    return count;                                                                                                 //
  }();                                                                                                            //
                                                                                                                  //
  return CooksList;                                                                                               //
}();                                                                                                              //
                                                                                                                  //
module.export("default",exports.default=(CooksList));                                                             //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["./collections/cooks",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/methods.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Cooks;module.import('./collections/cooks',{"default":function(v){Cooks=v}});                                  // 1
                                                                                                                  //
Meteor.methods({                                                                                                  // 3
  clearCooks: function () {                                                                                       // 4
    function clearCooks() {                                                                                       // 4
      Cooks.remove({});                                                                                           // 5
    }                                                                                                             // 6
                                                                                                                  //
    return clearCooks;                                                                                            // 4
  }()                                                                                                             // 4
});                                                                                                               // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"server":{"gitignore":{"google-calendar-refresh-token.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/gitignore/google-calendar-refresh-token.js                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
global.googleCalendarRefreshToken = "1/dKHJZAaUWC7C4ZmOrT99qHDKuXuVxsvyrEp8AWe_s7FIgOrJDtdun6zK6XiATCKT";         // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"google-client-secret.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/gitignore/google-client-secret.js                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
global.googleClientSecrets = { "web": { "client_id": "650934664824-9jkko6s2klfnsncep2h1bbl9n01fepju.apps.googleusercontent.com", "project_id": "poetic-genius-115422", "auth_uri": "https://accounts.google.com/o/oauth2/auth", "token_uri": "https://accounts.google.com/o/oauth2/token", "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs", "client_secret": "mPReJ6Hv-oJ3gcvDL2v2d6iY", "redirect_uris": ["http://dev.partialcinema.com/helper/auth", "http://dev.partialcinema.com:3000/helper/auth"] } };
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"calendar.js":["../lib/cooks-list","../lib/collections/cooks","../lib/collections/rehearsals","./cooks",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/calendar.js                                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var CookList;module.import('../lib/cooks-list',{"default":function(v){CookList=v}});var Cooks;module.import('../lib/collections/cooks',{"default":function(v){Cooks=v}});var Rehearsals;module.import('../lib/collections/rehearsals',{"default":function(v){Rehearsals=v}});var rebuildCooks;module.import('./cooks',{"default":function(v){rebuildCooks=v}});
                                                                                                                  // 2
                                                                                                                  // 3
                                                                                                                  // 4
                                                                                                                  //
rebuildCooks();                                                                                                   // 6
                                                                                                                  //
var cooks = new CookList();                                                                                       // 8
                                                                                                                  //
var google = Meteor.npmRequire("googleapis");                                                                     // 10
var scopes = ['https://www.googleapis.com/auth/calendar'];                                                        // 11
var CLIENT_ID = global.googleClientSecrets.web.client_id;                                                         // 12
var CLIENT_SECRET = global.googleClientSecrets.web.client_secret;                                                 // 13
                                                                                                                  //
var OAuth2 = google.auth.OAuth2;                                                                                  // 15
var oauth2Client = new OAuth2(CLIENT_ID, CLIENT_SECRET, 'http://dev.partialcinema.com:3000/helper/auth');         // 16
var accessToken = null;                                                                                           // 17
var refreshToken = global.googleCalendarRefreshToken;                                                             // 18
                                                                                                                  //
oauth2Client.setCredentials({                                                                                     // 20
  access_token: accessToken,                                                                                      // 21
  refresh_token: refreshToken                                                                                     // 22
});                                                                                                               // 20
                                                                                                                  //
var googleAuth = oauth2Client;                                                                                    // 25
var calendar = google.calendar({ version: 'v3', auth: googleAuth });                                              // 26
var moment = Meteor.npmRequire("moment");                                                                         // 27
                                                                                                                  //
var CALENDAR_IDS = {                                                                                              // 29
  rehearsal: 'scromh7crg9cm0u695pumsrb4o@group.calendar.google.com',                                              // 30
  show: 'm0crma3ead736lct9r0f88s1sk@group.calendar.google.com',                                                   // 31
  other: 'ghptaulpabvqsefm19cfhokh54@group.calendar.google.com'                                                   // 32
};                                                                                                                // 29
                                                                                                                  //
function listEvents(type, parameters, callback) {                                                                 // 35
  parameters.calendarId = CALENDAR_IDS[type];                                                                     // 36
  calendar.events.list(parameters, callback);                                                                     // 37
}                                                                                                                 // 38
                                                                                                                  //
function refreshRehearsals() {                                                                                    // 40
  console.log('');                                                                                                // 41
  console.log("Refreshing rehearsals.");                                                                          // 42
  var cookList = Cooks.findOne({});                                                                               // 43
  var todayStart = moment().hours(0).minutes(1);                                                                  // 44
  var lastRefreshedAt = moment(cookList.lastRefreshedAt) || todayStart;                                           // 45
  var oneWeekFromToday = todayStart.add(31, 'days');                                                              // 46
                                                                                                                  //
  console.log('Last refreshed at ' + lastRefreshedAt.format('LLL'));                                              // 48
  listEvents("rehearsal", { orderBy: "startTime", singleEvents: true, timeMin: lastRefreshedAt.format(), timeMax: oneWeekFromToday.format() }, Meteor.bindEnvironment(gotRehearsals));
                                                                                                                  //
  var pastRehearsals = 0;                                                                                         // 51
  function gotRehearsals(err, results) {                                                                          // 52
    if (err) {                                                                                                    // 53
      console.log("Error retrieving calendar events: ", err);                                                     // 54
      return;                                                                                                     // 55
    }                                                                                                             // 56
                                                                                                                  //
    Rehearsals.remove({});                                                                                        // 58
    var now = moment();                                                                                           // 59
    results.items.forEach(function (rehearsal) {                                                                  // 60
      var isPastRehearsal = moment(rehearsal.start.dateTime).isBefore(now);                                       // 61
      var humanReadableStartTime = moment(rehearsal.start.dateTime).format('LLL');                                // 62
      rehearsal.description = rehearsal.description || "";                                                        // 63
      var catered = rehearsal.description.indexOf("uncatered") < 0;                                               // 64
      console.log('Got event startin at ' + humanReadableStartTime);                                              // 65
      if (isPastRehearsal) {                                                                                      // 66
        pastRehearsals++;                                                                                         // 67
        cooks.cooked();                                                                                           // 68
      } else if (catered) {                                                                                       // 69
        Rehearsals.insert(rehearsal);                                                                             // 70
        if (Rehearsals.find().count() > cooks.count()) {                                                          // 71
          cooks.generateNextCook();                                                                               // 72
        }                                                                                                         // 73
      }                                                                                                           // 74
    });                                                                                                           // 75
                                                                                                                  //
    console.log('Found ' + pastRehearsals + ' past rehearsals');                                                  // 77
    Cooks.update(cookList._id, { $set: { lastRefreshedAt: now.toDate() } });                                      // 78
  }                                                                                                               // 79
}                                                                                                                 // 80
                                                                                                                  //
Meteor.startup(function () {                                                                                      // 82
  refreshRehearsals();                                                                                            // 83
});                                                                                                               // 84
                                                                                                                  //
Meteor.methods({                                                                                                  // 86
  refreshRehearsals: refreshRehearsals                                                                            // 87
});                                                                                                               // 86
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"cooks.js":["../lib/collections/cooks","../lib/cooks-list",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/cooks.js                                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({default:function(){return rebuildCooks}});var Cooks;module.import('../lib/collections/cooks',{"default":function(v){Cooks=v}});var CANNONICAL_COOKS;module.import('../lib/cooks-list',{"CANNONICAL_COOKS":function(v){CANNONICAL_COOKS=v}});
                                                                                                                  // 2
                                                                                                                  //
function rebuildCooks() {                                                                                         // 4
  var cookList = Cooks.findOne({});                                                                               // 5
                                                                                                                  //
  if (!cookList || !cookList.value || cookList.value.length === 0) {                                              // 7
    console.log('rebuilding cooks');                                                                              // 8
    Cooks.remove({});                                                                                             // 9
    Cooks.insert({ value: CANNONICAL_COOKS });                                                                    // 10
  }                                                                                                               // 11
}                                                                                                                 // 12
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/collections/cooks.js");
require("./lib/collections/rehearsals.js");
require("./lib/accounts-config.js");
require("./lib/cooks-list.js");
require("./lib/methods.js");
require("./server/gitignore/google-calendar-refresh-token.js");
require("./server/gitignore/google-client-secret.js");
require("./server/calendar.js");
require("./server/cooks.js");
//# sourceMappingURL=app.js.map
